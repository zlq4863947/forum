# CircleCI へのプロジェクト追加について


## Todo 初回時のみ
プロジェクト共通の変数を定義

### 共通変数
* NPM_TOKEN
    * npm のプライベートレポジトリを利用するのに利用

その他変数についても同様に定義することが可能  
特定プロジェクト内でしか使わない変数については該当プロジェクトの  
環境変数として定義すると良い

### 共通変数定義方法
1. 左端のSettingsをクリック
1. Settingsの最下部のContextsをクリック
1. Resources の箇所にVariableとValueの関係で定義
    * NPM_TOKENの場合は variable=NPM_TOKEN, value は定義された値

### その他
#### NPMのトークンの取得方法
1. コマンドプロンプト上でnpm loginで該当ユーザーにログイン
1. ログイン後、以下のファイルを開く ~/.npmrc
1. 以下の形式の最後のものを取得
    * //registry.npmjs.org/:_authToken=xxxx-xxxx-xxxx...



## ２回目以降
`.circleci/config.yml` を追加している状態でcircle-ci 上でプロジェクトを追加


