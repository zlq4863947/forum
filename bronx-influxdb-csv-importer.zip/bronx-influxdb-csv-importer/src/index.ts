#!/usr/bin/env node
import * as program from 'commander';
import { CsvImporter } from './lib/csvimporter';
import * as path from 'path';
const pckg = require('../package.json');

function range(val: string) {
  console.log('val:', val);
  return val.split('..').map(Number);
}

function list(val: string) {
  return val.split(',');
}

program
  .description('CSVファイルをinfluxDBにインポートする')
  .option(
    '-f, --file [value]',
    '入力CSVファイル(default:"./input.csv")',
    './input.csv'
  )
  .option('-o, --host [value]', 'ホスト(default:configファイルから指定)')
  .option('-d, --database [value]', 'データベース名(default:同上)')
  .option('-u, --username [value]', 'ユーザー名(default:同上)')
  .option('-p, --password [value]', 'パスワード(default:同上)')
  .option('-m, --measurement [value]', 'メジャメント名(default:data)', 'data')
  .option('-t, --tags <list>', 'tagカラム名。「,」で区切', list)
  .version(`Version: ${pckg.version}`);

program.parse(process.argv);

const csvIpter = new CsvImporter({
  host: program.host || null,
  database: program.database || null,
  username: program.username || null,
  password: program.password || null
});
const filepath = path.join(process.cwd(), program.file);
csvIpter.importCsv({filepath:filepath, measurement: program.measurement, tags: program.tags});
