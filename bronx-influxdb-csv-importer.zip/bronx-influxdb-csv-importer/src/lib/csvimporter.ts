import { point } from './types';
import { InfluxDB, IResults } from 'influx';
import csv = require('csvtojson');

const config = require('../../config/config');

export class CsvImporter {
  influx: InfluxDB;

  constructor(opt: { host?: string, database?: string, username?: string, password?: string }) {
    this.influx = new InfluxDB({
      host: opt.host || config.host,
      database: opt.database || config.database,
      username: opt.username || config.username,
      password: opt.password || config.password
    });
  }

  importCsv(opt: { filepath: string, measurement: string, tags: string[] }) {
    // return;

    csv().fromFile(opt.filepath).on('end_parsed', (jsonArray: any[]) => {
      if (jsonArray.length !== 0) {
        const points: point[] = [];
        for (const json of jsonArray) {
          const point = <point>{measurement: opt.measurement};
          // timestampが存在であれば、pointに追加する
          if (json['timestamp']) {
            point.timestamp = json['timestamp'];
            delete json['timestamp'];
          }
          const keys = Object.keys(json);
          const fieldKeys = Object.assign([], keys);

          // tagsの指定があれば、pointのtagsに追加する
          if (opt.tags && opt.tags.length !== 0) {
            point.tags = {};
            for (const tag of opt.tags) {
              if (keys.includes(tag)) {
                fieldKeys.splice(fieldKeys.indexOf(tag), 1);
                point.tags[tag] = json[tag];
              }
            }
          }
          point.fields = {};
          // pointのfieldsに追加する
          for (const key of fieldKeys) {
            point.fields[key] = json[key];
          }
          points.push(point);
        }
        this.influx.writePoints(points)
          .then(() => console.log('influxDBにインポートしました'))
          .catch((error: Error) => {
            if (error) {
              console.error(error.message);
            }
          });
      }
    }).on('done', (error: Error) => {
      if (error) {
        console.error(error.message);
      }
    });

  }

}


