export interface point {
    measurement: string,
    tags: { [key: string]: string },
    fields: {[key: string]: any },
    timestamp?: string|number
}
