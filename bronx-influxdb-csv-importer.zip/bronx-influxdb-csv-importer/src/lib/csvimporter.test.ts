import { CsvImporter } from './csvimporter';
import * as assert from 'power-assert';
import * as path from 'path';

const testImportCsv = async (done: () => void) => {

  const csvImporter = new CsvImporter({});
  const measurementName = 'data';
  await csvImporter.influx.dropMeasurement(measurementName);
  const filepath = path.join(process.cwd(), '/config/input.csv');
  csvImporter.importCsv({ filepath: filepath, measurement: measurementName, tags: ['open', 'close'] });
  // 1秒待つ
  await new Promise(resolve => setTimeout(resolve, 1000));

  const result: any[] = await csvImporter.influx.query(`select * from ${measurementName}`);

  assert(result.length !== 0);
  done();
};


describe('bronx-csvimporter', () => {

  it('should do test', function (done) {
    this.timeout(5000);
    testImportCsv(done);
  });

});
