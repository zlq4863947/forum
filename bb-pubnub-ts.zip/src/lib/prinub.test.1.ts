import * as assert from 'power-assert';
const pubnub = require('./pubnub');
// const log = require('bb-log');
// const tp = require('bb-tp');
const config = require('../../config/prinub');
/*

const tp = (f: any, interval: number) =>
new Promise((resolve, reject) =>
    setTimeout(() => {
        try {
            resolve(f())
        } catch (e) {
            reject(e)
        }
    }, interval)
)

const testInit = () => {
  assert(!pubnub.initialized());
  pubnub.init(config);
  assert(pubnub.initialized());
  assert(typeof pubnub.grant === 'function');
}
// const pubnub = new pubnub(config);

const testGrant = async () => {

  const channel = new Date().getTime().toString();
  const key = await pubnub.grant(channel);
  console.info('key: ' + key);
  assert(key.length === 64);
  return await pubnub.revoke(channel, key);
};

const testPublish = async () => {

  const channel = new Date().getTime().toString();
  const key = await pubnub.grant(channel);
  const tpKey = await tp(() => key, 1000);
  const pubkey = await pubnub.publish(channel, 'test1', { result: 'ok' });
  console.info('revoke: ' + pubkey)
};

const testSubscribe = async (done: any) => {

  const _channel = new Date().getTime().toString();
  const key = await pubnub.grant(_channel);
  await tp(() => key , 1000);
  console.info('key: ' + key);
  const s = await pubnub.subscribe([_channel], [key], (msg: any, channel: string) => {
    assert(channel === _channel);
    assert(msg);
    assert(msg.method === 'test2');
    assert(msg.params && msg.params.result === 'ok');
      console.info('message: ' , msg);
  });

    console.info('publish: ' , key);
    await pubnub.publish(_channel, 'test2', { result: 'ok' });

    console.info('revoke: ' , key);
    await pubnub.revoke(_channel, key);
    done();
}

testInit();
/*
describe('bb-pubnub-ts', () => {
  it('should do testInit', testInit);
 // it('should do testGrant', testGrant);
 // it('should do testPublish', testPublish);
  /*it('should do testSubscribe',  function (done) {
      this.timeout(20000);
      testSubscribe(done);
  });*/

  // .then(() => {done()})

/*}); */
