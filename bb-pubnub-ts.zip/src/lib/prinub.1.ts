import * as types from './types';
import * as crypto from 'crypto';
const assert = require('assert')
const PriNub = require('class-pubnub');
const util = require('util');
// const log = require('bb-log');

let _initialized = false
exports.initialized = () => _initialized;

exports.init = (config: types.PriNubOptions) => {
  assert(!_initialized, 'already initialized.');
  const prinub = new PriNub(config);

  exports.grant = grant(prinub);

  _initialized = true;

}

const grant = (prinub: any) => (channel: string) =>
  prinub.read(channel)
    .then((key: string) => {
      prinub.write(channel)
      return key
    })
