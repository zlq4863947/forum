export interface PubNub {
    grant: any;
    setAuthKey: any;
    publish: any;
}

export interface PriNubOptions {
    publishKey: string;
    subscribeKey: string;
    secretKey: string;
    salt: string;
    ttl?: number;
}

export interface PubNubOptions {
    publishKey: string;
    subscribeKey: string;
    pubnub: PubNub;
}

export interface GrantOptions {
    pubnub: PubNub;
    channel: string|string[];
    key: string|string[];
    write: boolean;
    read: boolean;
    ttl?: number;
}
