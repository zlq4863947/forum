import * as assert from 'power-assert';
import * as types from './types';
const PUBNUB = require('pubnub');
// const log = require('bb-log');
/*
export class PriNub {
  private opt: types.PubNubOptions;
  private pubnub: types.PubNub;
  private _grant: Grant;

  constructor(config: types.PubNubOptions) {
    this.opt = config;
    this.pubnub = new PUBNUB(
      Object.assign({
        subscribeKey: this.opt.subscribeKey,
        ssl: true,
        keepAlive: true,
        keepAliveSettings: {
          maxSockets: 128,
          timeout: 5000
        },
        error: (e: any) => {
          throw e;
        }
      },
        this.opt.publishKey ? { publishKey: this.opt.publishKey } : {})
    );
  }

  publish(channel: string, method: string, params: any) {
    const message = { method, params: params || {} };
    const key = this._grant.createWriteAuthKey(channel);
    this.opt.pubnub.setAuthKey(key);
    return new Promise((resolve, reject) =>
      this.opt.pubnub.publish({ channel, message },
        (status: any) => {
          if (status.error) {
            const e = new Error('PubNub connection error. status.error: ' + util.inspect(status.error, false, null))
            reject(e)
          }
          resolve(key)
        }
      )
    )
  }
  async subscribe(channels: string[], key: string[], callback: any) {
    const subnub = new PUBNUB({
      subscribeKey: this.opt.subscribeKey,
      authKey: key,
      ssl: true,
      error: (e: any) => { throw e }
    });
    return new Promise((resolve, reject) => {

      let category: string;
      setTimeout(() => reject(
        new Error('PubNub cannnot connect in 3000. category: ' + category)
      ), 3000)

      const status = (s: any) => {
        category = s.category
        if (category === 'PNConnectedCategory') {
          resolve()
        }
      }

      const message = (obj: any) => {
        if (channels.some(channel => channel === obj.channel)) {
          return Promise.resolve()
            .then(() => callback(obj.message, obj.channel, obj.timetoken))
            .catch(e => console.error(e.stack))
        }
      }

      subnub.addListener({ status, message })
      subnub.subscribe({ channels })
    })
  }
}

class Grant {
  config: types.PubNubOptions;

  constructor(config: types.PubNubOptions) {
    this.config = config;
  }

  private _grant(opt: types.GrantOptions): Promise<string> {
    return new Promise((resolve, reject) => {
      return opt.pubnub.grant({
        channels: Array.isArray(opt.channel) ? opt.channel : [opt.channel],
        authKeys: Array.isArray(opt.key) ? opt.key : [opt.key],
        ttl: opt.ttl,
        read: opt.read,
        write: opt.write
      }, (status: any) => {
        return status.error ? reject(status) : resolve(opt.key.toString());
      });
    });
  }

  createWriteAuthKey(channel: string) {
    return crypto.createHmac('sha256', this.config.salt).update(channel).digest('hex');
  }

  createReadAuthKey(channel: string) {
    return new Promise((resolve, reject) =>
      crypto.randomBytes(32, (e, buf) =>
        e ? reject(e) : resolve(buf)
      )
    )
      .then((buf: string | Buffer) => {
        return crypto.createHash('sha256')
          .update(buf)
          .digest('hex');
      });
  }

  write(channel: string) {
    const key = this.createWriteAuthKey(channel);
    const grantOpt = {
      pubnub: this.config.pubnub,
      channel,
      key,
      read: true,
      write: true,
      ttl: this.config.ttl
    };
    return this._grant(grantOpt);
  }

  async read(channel: string) {
    const key = await this.createReadAuthKey(channel);
    const grantOpt = {
      pubnub: this.config.pubnub,
      channel,
      key,
      read: true,
      write: false,
      ttl: this.config.ttl
    };
    return this._grant(grantOpt);
  }

  revoke(channel: string | string[], key: string | string[]) {
    const grantOpt = {
      pubnub: this.config.pubnub,
      channel,
      key,
      read: false,
      write: false,
      ttl: 0
    };
    return this._grant(grantOpt);
  }
}*/
